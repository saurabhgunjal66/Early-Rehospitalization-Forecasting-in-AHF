import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import os
import hashlib

# Import custom modules
from auth import AuthManager
from data_generator import SyntheticDataGenerator
from models import AHFPredictionModels
from database import DatabaseManager
from notifications import NotificationManager
from explainability import ExplainabilityManager
from monitoring import ModelMonitor
from reporting import ReportGenerator
from data_validation import DataValidator
from alert_system import AlertSystem

# Page configuration
st.set_page_config(
    page_title="AHF Rehospitalization Predictor",
    page_icon="🫀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
if 'user_role' not in st.session_state:
    st.session_state.user_role = None
if 'username' not in st.session_state:
    st.session_state.username = None
if 'alert_thresholds' not in st.session_state:
    st.session_state.alert_thresholds = {'high_risk': 0.7, 'medium_risk': 0.5}

# Initialize managers
@st.cache_resource
def init_managers():
    auth_manager = AuthManager()
    db_manager = DatabaseManager()
    models = AHFPredictionModels()
    notification_manager = NotificationManager()
    explainability = ExplainabilityManager()
    monitor = ModelMonitor(db_manager)
    report_generator = ReportGenerator(db_manager)
    data_validator = DataValidator()
    alert_system = AlertSystem(db_manager, notification_manager)
    data_generator = SyntheticDataGenerator()
    
    return {
        'auth': auth_manager,
        'db': db_manager,
        'models': models,
        'notifications': notification_manager,
        'explainability': explainability,
        'monitor': monitor,
        'reports': report_generator,
        'validator': data_validator,
        'alerts': alert_system,
        'data_generator': data_generator
    }

managers = init_managers()

def login_page():
    """Display login page."""
    st.title("🫀 AHF Rehospitalization Predictor")
    st.subheader("Healthcare Provider Login")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Login")
            
            if submitted:
                user = managers['auth'].authenticate_user(username, password)
                if user:
                    st.session_state.authenticated = True
                    st.session_state.username = username
                    st.session_state.user_role = user['role']
                    st.success(f"Welcome, {username}!")
                    st.rerun()
                else:
                    st.error("Invalid credentials")
        
        st.markdown("---")
        st.subheader("Register New User")
        
        with st.form("register_form"):
            new_username = st.text_input("New Username")
            new_password = st.text_input("New Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")
            role = st.selectbox("Role", ["Doctor", "Nurse", "Admin"])
            email = st.text_input("Email Address")
            
            register_submitted = st.form_submit_button("Register")
            
            if register_submitted:
                if new_password != confirm_password:
                    st.error("Passwords don't match")
                elif len(new_password) < 6:
                    st.error("Password must be at least 6 characters")
                elif managers['auth'].create_user(new_username, new_password, role, email):
                    st.success("User registered successfully! Please login.")
                else:
                    st.error("Username already exists")

def main_dashboard():
    """Main application dashboard."""
    # Sidebar navigation
    st.sidebar.title(f"Welcome, {st.session_state.username}")
    st.sidebar.write(f"Role: {st.session_state.user_role}")
    
    # Navigation menu
    pages = {
        "Risk Assessment": "🏥",
        "Patient Monitoring": "📊",
        "Model Performance": "📈",
        "Alerts & Notifications": "🚨",
        "Reports": "📄"
    }
    
    if st.session_state.user_role == "Admin":
        pages["System Administration"] = "⚙️"
    
    selected_page = st.sidebar.selectbox(
        "Navigation",
        list(pages.keys()),
        format_func=lambda x: f"{pages[x]} {x}"
    )
    
    # Logout button
    if st.sidebar.button("Logout"):
        st.session_state.authenticated = False
        st.session_state.user_role = None
        st.session_state.username = None
        st.rerun()
    
    # Main content based on selected page
    if selected_page == "Risk Assessment":
        risk_assessment_page()
    elif selected_page == "Patient Monitoring":
        patient_monitoring_page()
    elif selected_page == "Model Performance":
        model_performance_page()
    elif selected_page == "Alerts & Notifications":
        alerts_notifications_page()
    elif selected_page == "Reports":
        reports_page()
    elif selected_page == "System Administration":
        admin_page()

def risk_assessment_page():
    """Risk assessment interface."""
    st.title("🏥 Patient Risk Assessment")
    
    # Check if models are trained
    if not managers['models'].models_trained():
        st.warning("Models not trained. Training with synthetic data...")
        train_models()
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Patient Information")
        
        with st.form("patient_assessment"):
            # Patient demographics
            col_demo1, col_demo2 = st.columns(2)
            with col_demo1:
                patient_id = st.text_input("Patient ID", value=f"PAT_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
                age = st.number_input("Age", min_value=18, max_value=100, value=65)
                gender = st.selectbox("Gender", ["Male", "Female"])
                weight = st.number_input("Weight (kg)", min_value=30.0, max_value=200.0, value=75.0, step=0.1)
            
            with col_demo2:
                nt_probnp = st.number_input("NT-proBNP (pg/mL)", min_value=50.0, max_value=50000.0, value=2000.0, step=10.0)
                creatinine = st.number_input("Creatinine (mg/dL)", min_value=0.5, max_value=5.0, value=1.2, step=0.1)
                ejection_fraction = st.number_input("Ejection Fraction (%)", min_value=10, max_value=80, value=40)
                systolic_bp = st.number_input("Systolic BP (mmHg)", min_value=80, max_value=200, value=120)
            
            # Ultrasound parameters
            st.subheader("Ultrasound Parameters")
            col_us1, col_us2 = st.columns(2)
            with col_us1:
                b_line_score = st.number_input("B-line Score", min_value=0, max_value=28, value=8)
                ivc_collapsibility = st.number_input("IVC Collapsibility (%)", min_value=0.0, max_value=100.0, value=50.0, step=1.0)
            
            with col_us2:
                heart_rate = st.number_input("Heart Rate (bpm)", min_value=40, max_value=180, value=75)
            
            # Comorbidities
            st.subheader("Comorbidities")
            col_comor1, col_comor2 = st.columns(2)
            with col_comor1:
                diabetes = st.checkbox("Diabetes")
                hypertension = st.checkbox("Hypertension")
            with col_comor2:
                ckd = st.checkbox("Chronic Kidney Disease")
                afib = st.checkbox("Atrial Fibrillation")
            
            submitted = st.form_submit_button("Assess Risk", type="primary")
            
            if submitted:
                # Validate data
                patient_data = {
                    'patient_id': patient_id,
                    'age': age,
                    'gender': 1 if gender == "Male" else 0,
                    'weight': weight,
                    'nt_probnp': nt_probnp,
                    'creatinine': creatinine,
                    'b_line_score': b_line_score,
                    'ivc_collapsibility': ivc_collapsibility,
                    'ejection_fraction': ejection_fraction,
                    'systolic_bp': systolic_bp,
                    'heart_rate': heart_rate,
                    'diabetes': 1 if diabetes else 0,
                    'hypertension': 1 if hypertension else 0,
                    'ckd': 1 if ckd else 0,
                    'afib': 1 if afib else 0
                }
                
                # Validate input data
                validation_result = managers['validator'].validate_patient_data(patient_data)
                
                if validation_result['valid']:
                    # Get predictions
                    predictions = managers['models'].predict_risk(patient_data)
                    
                    # Calculate ensemble probability
                    ensemble_prob = (predictions['logistic_regression']['probability'] + 
                                   predictions['xgboost']['probability']) / 2
                    
                    # Determine risk level
                    if ensemble_prob >= st.session_state.alert_thresholds['high_risk']:
                        risk_level = "High Risk"
                        risk_color = "red"
                    elif ensemble_prob >= st.session_state.alert_thresholds['medium_risk']:
                        risk_level = "Moderate Risk"
                        risk_color = "orange"
                    else:
                        risk_level = "Low Risk"
                        risk_color = "green"
                    
                    # Save assessment
                    assessment_record = {
                        'patient_id': patient_id,
                        'assessment_date': datetime.now().isoformat(),
                        'age': age,
                        'gender': gender,
                        'weight': weight,
                        'nt_probnp': nt_probnp,
                        'creatinine': creatinine,
                        'b_line_score': b_line_score,
                        'ivc_collapsibility': ivc_collapsibility,
                        'ejection_fraction': ejection_fraction,
                        'systolic_bp': systolic_bp,
                        'heart_rate': heart_rate,
                        'diabetes': 1 if diabetes else 0,
                        'hypertension': 1 if hypertension else 0,
                        'ckd': 1 if ckd else 0,
                        'afib': 1 if afib else 0,
                        'lr_probability': predictions['logistic_regression']['probability'],
                        'xgb_probability': predictions['xgboost']['probability'],
                        'ensemble_probability': ensemble_prob,
                        'risk_level': risk_level
                    }
                    
                    managers['db'].save_assessment(assessment_record)
                    
                    # Check for alerts
                    managers['alerts'].check_and_send_alerts(patient_data, ensemble_prob, risk_level)
                    
                    # Display results in sidebar
                    with col2:
                        display_risk_results(predictions, ensemble_prob, risk_level, risk_color, patient_data)
                else:
                    st.error("Data validation failed:")
                    for error in validation_result['errors']:
                        st.error(f"• {error}")

def display_risk_results(predictions, ensemble_prob, risk_level, risk_color, patient_data):
    """Display risk assessment results."""
    st.subheader("Risk Assessment Results")
    
    # Risk gauge
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=ensemble_prob * 100,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "30-Day Readmission Risk (%)"},
        gauge={
            'axis': {'range': [0, 100]},
            'bar': {'color': risk_color},
            'steps': [
                {'range': [0, 50], 'color': "lightgreen"},
                {'range': [50, 70], 'color': "yellow"},
                {'range': [70, 100], 'color': "lightcoral"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 70
            }
        }
    ))
    fig_gauge.update_layout(height=300)
    st.plotly_chart(fig_gauge, use_container_width=True)
    
    # Risk level
    if risk_level == "High Risk":
        st.error(f"🚨 {risk_level}: {ensemble_prob:.1%}")
    elif risk_level == "Moderate Risk":
        st.warning(f"⚠️ {risk_level}: {ensemble_prob:.1%}")
    else:
        st.success(f"✅ {risk_level}: {ensemble_prob:.1%}")
    
    # Model predictions
    st.subheader("Model Predictions")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Logistic Regression", f"{predictions['logistic_regression']['probability']:.1%}")
    with col2:
        st.metric("XGBoost", f"{predictions['xgboost']['probability']:.1%}")
    
    # SHAP explanation
    st.subheader("Risk Factor Analysis")
    try:
        shap_explanation = managers['explainability'].explain_prediction(patient_data)
        if shap_explanation:
            st.plotly_chart(shap_explanation['plot'], use_container_width=True)
            
            # Top contributing factors
            top_factors = shap_explanation['top_factors']
            st.write("**Top Contributing Factors:**")
            for factor, contribution in top_factors.items():
                if contribution > 0:
                    st.write(f"• {factor}: Increases risk (+{contribution:.3f})")
                else:
                    st.write(f"• {factor}: Decreases risk ({contribution:.3f})")
    except Exception as e:
        st.error(f"Unable to generate SHAP explanation: {str(e)}")

def patient_monitoring_page():
    """Patient monitoring dashboard."""
    st.title("📊 Patient Monitoring Dashboard")
    
    # Get all assessments
    assessments = managers['db'].get_all_assessments()
    
    if not assessments:
        st.info("No patient assessments found. Please perform risk assessments first.")
        return
    
    df = pd.DataFrame(assessments)
    df['assessment_date'] = pd.to_datetime(df['assessment_date'])
    
    # Filters
    col1, col2, col3 = st.columns(3)
    with col1:
        date_range = st.date_input(
            "Date Range",
            value=(df['assessment_date'].min().date(), df['assessment_date'].max().date()),
            min_value=df['assessment_date'].min().date(),
            max_value=df['assessment_date'].max().date()
        )
    
    with col2:
        risk_filter = st.multiselect(
            "Risk Level",
            ["Low Risk", "Moderate Risk", "High Risk"],
            default=["Low Risk", "Moderate Risk", "High Risk"]
        )
    
    with col3:
        patient_filter = st.multiselect(
            "Patient ID",
            df['patient_id'].unique(),
            default=[]
        )
    
    # Apply filters
    filtered_df = df[
        (df['assessment_date'].dt.date >= date_range[0]) &
        (df['assessment_date'].dt.date <= date_range[1]) &
        (df['risk_level'].isin(risk_filter))
    ]
    
    if patient_filter:
        filtered_df = filtered_df[filtered_df['patient_id'].isin(patient_filter)]
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Assessments", len(filtered_df))
    with col2:
        high_risk_count = len(filtered_df[filtered_df['risk_level'] == 'High Risk'])
        st.metric("High Risk Patients", high_risk_count)
    with col3:
        avg_risk = filtered_df['ensemble_probability'].mean() if len(filtered_df) > 0 else 0
        st.metric("Average Risk Score", f"{avg_risk:.1%}")
    with col4:
        unique_patients = filtered_df['patient_id'].nunique()
        st.metric("Unique Patients", unique_patients)
    
    # Risk distribution
    st.subheader("Risk Distribution")
    fig_dist = px.histogram(
        filtered_df, 
        x='ensemble_probability', 
        nbins=20,
        title="Distribution of Risk Scores",
        labels={'ensemble_probability': 'Risk Score', 'count': 'Number of Assessments'}
    )
    fig_dist.add_vline(x=st.session_state.alert_thresholds['medium_risk'], 
                      line_dash="dash", line_color="orange", 
                      annotation_text="Medium Risk Threshold")
    fig_dist.add_vline(x=st.session_state.alert_thresholds['high_risk'], 
                      line_dash="dash", line_color="red", 
                      annotation_text="High Risk Threshold")
    st.plotly_chart(fig_dist, use_container_width=True)
    
    # Biomarker trends
    if len(filtered_df) > 1:
        st.subheader("Biomarker Trends")
        
        # Select biomarker to display
        biomarker = st.selectbox(
            "Select Biomarker",
            ["nt_probnp", "weight", "creatinine", "b_line_score", "ivc_collapsibility", "ejection_fraction"]
        )
        
        # Create trend plot
        fig_trend = px.scatter(
            filtered_df.sort_values('assessment_date'),
            x='assessment_date',
            y=biomarker,
            color='risk_level',
            size='ensemble_probability',
            hover_data=['patient_id'],
            title=f"{biomarker.replace('_', ' ').title()} Trends Over Time",
            color_discrete_map={
                'Low Risk': 'green',
                'Moderate Risk': 'orange', 
                'High Risk': 'red'
            }
        )
        st.plotly_chart(fig_trend, use_container_width=True)
    
    # Recent assessments table
    st.subheader("Recent Assessments")
    display_columns = [
        'assessment_date', 'patient_id', 'risk_level', 'ensemble_probability',
        'nt_probnp', 'weight', 'creatinine', 'age'
    ]
    
    recent_assessments = filtered_df.nlargest(20, 'assessment_date')[display_columns]
    recent_assessments['assessment_date'] = recent_assessments['assessment_date'].dt.strftime('%Y-%m-%d %H:%M')
    recent_assessments['ensemble_probability'] = recent_assessments['ensemble_probability'].apply(lambda x: f"{x:.1%}")
    
    st.dataframe(recent_assessments, use_container_width=True)

def model_performance_page():
    """Model performance monitoring."""
    st.title("📈 Model Performance Monitoring")
    
    # Performance metrics
    if managers['models'].models_trained():
        metrics = managers['models'].get_performance_metrics()
        
        if metrics:
            st.subheader("Current Model Performance")
            
            # Metrics comparison
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Logistic Regression**")
                lr_metrics = metrics['logistic_regression']
                
                perf_col1, perf_col2 = st.columns(2)
                with perf_col1:
                    st.metric("Accuracy", f"{lr_metrics['accuracy']:.3f}")
                    st.metric("Sensitivity", f"{lr_metrics['sensitivity']:.3f}")
                with perf_col2:
                    st.metric("AUC", f"{lr_metrics['auc']:.3f}")
                    st.metric("Specificity", f"{lr_metrics['specificity']:.3f}")
            
            with col2:
                st.write("**XGBoost**")
                xgb_metrics = metrics['xgboost']
                
                perf_col1, perf_col2 = st.columns(2)
                with perf_col1:
                    st.metric("Accuracy", f"{xgb_metrics['accuracy']:.3f}")
                    st.metric("Sensitivity", f"{xgb_metrics['sensitivity']:.3f}")
                with perf_col2:
                    st.metric("AUC", f"{xgb_metrics['auc']:.3f}")
                    st.metric("Specificity", f"{xgb_metrics['specificity']:.3f}")
            
            # ROC Curves
            st.subheader("ROC Curves")
            roc_fig = managers['monitor'].create_roc_comparison(metrics)
            if roc_fig:
                st.plotly_chart(roc_fig, use_container_width=True)
            
            # Feature importance
            st.subheader("Feature Importance (XGBoost)")
            importance = managers['models'].get_feature_importance()
            if importance:
                importance_df = pd.DataFrame(list(importance.items()), columns=['Feature', 'Importance'])
                fig_importance = px.bar(
                    importance_df.head(10),
                    x='Importance',
                    y='Feature',
                    orientation='h',
                    title="Top 10 Most Important Features"
                )
                st.plotly_chart(fig_importance, use_container_width=True)
            
            # Confusion matrices
            st.subheader("Confusion Matrices")
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Logistic Regression**")
                cm_fig_lr = managers['monitor'].create_confusion_matrix_plot(
                    lr_metrics['confusion_matrix'], "Logistic Regression"
                )
                if cm_fig_lr:
                    st.plotly_chart(cm_fig_lr, use_container_width=True)
            
            with col2:
                st.write("**XGBoost**")
                cm_fig_xgb = managers['monitor'].create_confusion_matrix_plot(
                    xgb_metrics['confusion_matrix'], "XGBoost"
                )
                if cm_fig_xgb:
                    st.plotly_chart(cm_fig_xgb, use_container_width=True)
        
        # Model drift monitoring
        st.subheader("Model Drift Monitoring")
        drift_data = managers['monitor'].check_model_drift()
        if drift_data:
            st.plotly_chart(drift_data['plot'], use_container_width=True)
        else:
            st.info("Insufficient data for drift analysis. More assessments needed.")
    
    else:
        st.warning("Models not trained yet.")
        if st.button("Train Models"):
            train_models()

def alerts_notifications_page():
    """Alerts and notifications management."""
    st.title("🚨 Alerts & Notifications")
    
    # Alert configuration
    st.subheader("Alert Configuration")
    
    col1, col2 = st.columns(2)
    with col1:
        high_risk_threshold = st.slider(
            "High Risk Threshold",
            min_value=0.5,
            max_value=1.0,
            value=st.session_state.alert_thresholds['high_risk'],
            step=0.05
        )
    
    with col2:
        medium_risk_threshold = st.slider(
            "Medium Risk Threshold",
            min_value=0.3,
            max_value=0.8,
            value=st.session_state.alert_thresholds['medium_risk'],
            step=0.05
        )
    
    if st.button("Update Thresholds"):
        st.session_state.alert_thresholds = {
            'high_risk': high_risk_threshold,
            'medium_risk': medium_risk_threshold
        }
        st.success("Alert thresholds updated!")
    
    # Email notification settings
    st.subheader("Email Notification Settings")
    
    with st.form("notification_settings"):
        email_enabled = st.checkbox("Enable Email Notifications", value=True)
        notification_emails = st.text_area(
            "Notification Recipients (one email per line)",
            value="doctor@hospital.com\nnurse@hospital.com"
        )
        
        # Test email
        test_email = st.text_input("Test Email Address")
        
        col1, col2 = st.columns(2)
        with col1:
            save_settings = st.form_submit_button("Save Settings")
        with col2:
            send_test = st.form_submit_button("Send Test Email")
        
        if save_settings:
            # Save notification settings
            emails = [email.strip() for email in notification_emails.split('\n') if email.strip()]
            managers['notifications'].update_notification_settings({
                'enabled': email_enabled,
                'recipients': emails
            })
            st.success("Notification settings saved!")
        
        if send_test and test_email:
            success = managers['notifications'].send_test_email(test_email)
            if success:
                st.success(f"Test email sent to {test_email}")
            else:
                st.error("Failed to send test email. Check your email configuration.")
    
    # Recent alerts
    st.subheader("Recent Alerts")
    recent_alerts = managers['alerts'].get_recent_alerts()
    
    if recent_alerts:
        alerts_df = pd.DataFrame(recent_alerts)
        st.dataframe(alerts_df, use_container_width=True)
    else:
        st.info("No recent alerts found.")
    
    # Alert statistics
    st.subheader("Alert Statistics")
    alert_stats = managers['alerts'].get_alert_statistics()
    
    if alert_stats:
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Alerts (24h)", alert_stats.get('alerts_24h', 0))
        with col2:
            st.metric("High Risk Alerts (7d)", alert_stats.get('high_risk_7d', 0))
        with col3:
            st.metric("Response Rate", f"{alert_stats.get('response_rate', 0):.1%}")

def reports_page():
    """Reports generation and management."""
    st.title("📄 Reports")
    
    # Report generation
    st.subheader("Generate Reports")
    
    col1, col2 = st.columns(2)
    
    with col1:
        report_type = st.selectbox(
            "Report Type",
            ["Daily Summary", "Weekly Summary", "Monthly Summary", "High Risk Patients", "Model Performance"]
        )
    
    with col2:
        report_format = st.selectbox(
            "Format",
            ["PDF", "CSV", "Excel"]
        )
    
    if report_type in ["Weekly Summary", "Monthly Summary"]:
        date_from = st.date_input("From Date", value=datetime.now() - timedelta(days=7))
        date_to = st.date_input("To Date", value=datetime.now())
    else:
        date_from = date_to = datetime.now()
    
    if st.button("Generate Report"):
        with st.spinner("Generating report..."):
            report_data = managers['reports'].generate_report(
                report_type.lower().replace(' ', '_'),
                date_from,
                date_to,
                report_format.lower()
            )
            
            if report_data:
                st.success("Report generated successfully!")
                
                if report_format == "PDF":
                    with open(report_data['filename'], 'rb') as f:
                        st.download_button(
                            label="Download PDF Report",
                            data=f.read(),
                            file_name=report_data['filename'],
                            mime="application/pdf"
                        )
                else:
                    st.download_button(
                        label=f"Download {report_format} Report",
                        data=report_data['data'],
                        file_name=report_data['filename'],
                        mime=report_data['mime_type']
                    )
            else:
                st.error("Failed to generate report.")
    
    # Recent reports
    st.subheader("Recent Reports")
    recent_reports = managers['reports'].get_recent_reports()
    
    if recent_reports:
        reports_df = pd.DataFrame(recent_reports)
        st.dataframe(reports_df, use_container_width=True)
    else:
        st.info("No recent reports found.")

def admin_page():
    """Administration interface (Admin only)."""
    if st.session_state.user_role != "Admin":
        st.error("Access denied. Admin privileges required.")
        return
    
    st.title("⚙️ System Administration")
    
    # Database statistics
    st.subheader("Database Statistics")
    db_stats = managers['db'].get_database_stats()
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Records", db_stats['total_records'])
    with col2:
        st.metric("DB Size (MB)", f"{db_stats['db_size_mb']:.2f}")
    with col3:
        st.metric("Last Update", db_stats['last_update'])
    
    # User management
    st.subheader("User Management")
    users = managers['auth'].get_all_users()
    
    if users:
        users_df = pd.DataFrame(users)
        st.dataframe(users_df[['username', 'role', 'email', 'created_at']], use_container_width=True)
    
    # System controls
    st.subheader("System Controls")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Retrain Models"):
            train_models()
    
    with col2:
        if st.button("Clear All Data"):
            if st.checkbox("Confirm data deletion"):
                managers['db'].clear_all_records()
                st.success("All data cleared!")
    
    with col3:
        if st.button("Export All Data"):
            filename = managers['db'].export_to_csv()
            if filename:
                st.success(f"Data exported to {filename}")

def train_models():
    """Train ML models with synthetic data."""
    with st.spinner("Training models..."):
        # Generate synthetic data
        data_generator = managers['data_generator']
        training_data = data_generator.generate_training_dataset(2000)
        
        # Train models
        managers['models'].train_models(training_data)
        
        # Save performance metrics to database
        metrics = managers['models'].get_performance_metrics()
        if metrics:
            managers['db'].save_model_performance('logistic_regression', metrics['logistic_regression'])
            managers['db'].save_model_performance('xgboost', metrics['xgboost'])
        
        st.success("Models trained successfully!")
        st.rerun()

# Main application flow
if not st.session_state.authenticated:
    login_page()
else:
    main_dashboard()
